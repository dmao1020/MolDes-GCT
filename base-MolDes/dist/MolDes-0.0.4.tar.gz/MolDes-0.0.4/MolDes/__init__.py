from MolDes import GCT_util
from MolDes import CM_util